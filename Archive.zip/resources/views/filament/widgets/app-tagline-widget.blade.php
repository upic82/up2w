<x-filament::widget>
    <div class="px-4 py-3 bg-white shadow rounded-lg">
        <h1 class="text-xl font-bold text-gray-800">ProWorx</h1>
        <p class="text-sm text-gray-600">Integrated System for Production & Workshop Excellence</p>
    </div>
</x-filament::widget>
