<div class="p-4 bg-yellow-50 text-yellow-800 rounded-lg">
    <p>Data penugasan tidak ditemukan untuk DKMJ ini.</p>
</div>