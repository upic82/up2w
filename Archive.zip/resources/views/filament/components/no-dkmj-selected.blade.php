<div class="p-4 bg-yellow-50 text-yellow-800 rounded-lg">
    <p>Silakan pilih atau buat DKMJ terlebih dahulu untuk melihat actual pengadaan.</p>
</div>