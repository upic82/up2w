<?php

namespace App\Filament\Resources\PenugasanResource\Pages;

use App\Filament\Resources\PenugasanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePenugasan extends CreateRecord
{
    protected static string $resource = PenugasanResource::class;
}
